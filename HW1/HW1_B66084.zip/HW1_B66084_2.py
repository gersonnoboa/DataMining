import pandas as pd
import numpy as np

from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"

abalone = pd.read_csv("abalone.csv")

#a. What are the column names of the dataset?
list(abalone)

#b. How many observations (i.e. rows) are in this data frame?
len(abalone.index)

#c. Print the first 4 lines from the dataset. What are the values of feature rings of the printed observations?
four = abalone.head(4)
print(four)
four["Rings"]

#d. Extract the last 3 rows of the data frame. What is the weight of these abalones?
three = abalone.tail(3)
print(three)
three["Weight"]

#e. What is the value of diameter in the row 755?
abalone["Diameter"][754]

#f. How many missing values are in the height column?
abalone["Height"].isnull().values.sum()

#g. What is the mean of the height column? Exclude missing values from this calculation.
abalone.Height.mean(skipna = True)

#h. Extract the subset of rows of the data frame where gender is M and weight values are below 0.75. 
#What is the mean of diameter in this subset?
sub = abalone[(abalone["Gender"] == "M") & (abalone["Weight"] < 0.75)]
sub.Diameter.mean()

#i. What is the most frequent rings value?
abalone.Rings.mode()

#j. What is the minimum of length when rings is equal to 18?
sub2 = abalone[(abalone.Rings == 18)]
min(sub2.Length)