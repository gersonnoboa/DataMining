abalone = read.table('abalone.csv', header = T, stringsAsFactors = F, sep = ",")

#a. What are the column names of the dataset?
colnames(abalone)

#b. How many observations (i.e. rows) are in this data frame?
nrow(abalone)

#c. Print the first 4 lines from the dataset. What are the values of feature rings of the printed observations?
print(abalone[c(1:4),])

abalone$Rings[c(1:4)]

#d. Extract the last 3 rows of the data frame. What is the weight of these abalones?
last3 = tail(abalone, 3)
print(last3)
last3$Weight

#e. What is the value of diameter in the row 755?
abalone$Diameter[755]

#f. How many missing values are in the height column?
missing = abalone$Height[!complete.cases(abalone)]
length(missing)

#g. What is the mean of the height column? Exclude missing values from this calculation.
mean(abalone$Height, na.rm=TRUE)

#h. Extract the subset of rows of the data frame where gender is M and weight values are below 0.75. 
#What is the mean of diameter in this subset?
sub = subset(abalone, Gender == 'M' & Weight < 0.75)
print(sub)
mean(sub$Diameter)

#i. What is the most frequent rings value?
##for getting the mode and the number of times it appears in the data set
mode = sort(table(abalone$Rings),decreasing=TRUE)[1]
print(mode)

##for getting only the mode
as.numeric(names(mode))

#j. What is the minimum of length when rings is equal to 18?
sub2 = subset(abalone, Rings == 18)
min(sub2$Length)x